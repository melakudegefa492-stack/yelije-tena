የልጄ ጤና (Yelije Tena) — የWeb App ፋይሎች

ይዘቱ:
- index.html: ዋናው Web App
- manifest.webmanifest: ወደ ስልክ እንደ App ለመጫን የሚያግዝ
- sw.js: አንዳንድ ይዘቶችን ከመስመር ውጭ ለማስኬድ
- icon.svg: የApp አዶ
- 40 የምግብ ምርጫዎች: 10 ቁርስ፣ 10 ምሳ፣ 10 መክሰስ፣ 10 እራት

በAndroid ላይ ለመሞከር:
1. ZIP-ውን ያውርዱና ይክፈቱ።
2. index.html ይክፈቱ። በአካባቢያዊ ፋይል ሲከፈት የPWA install ባህሪ ላይሰራ ይችላል።
3. የስልክ ማያ ገጽ ላይ እንደ App ለመጫን በHTTPS የተስተናገደ ድረ-ገጽ ያስፈልጋል።

በኢንተርኔት ላይ ለማተም (GitHub Pages ምሳሌ):
1. GitHub መለያ ይፍጠሩ/ይግቡ።
2. አዲስ repository ይፍጠሩ።
3. ከZIP ውስጥ ያሉትን index.html, manifest.webmanifest, sw.js, icon.svg ወደ repository ያስገቡ።
4. Repository Settings > Pages ውስጥ Deploy from a branch ይምረጡ፤ branch main እና folder /(root) ይምረጡ።
5. GitHub የሚሰጥዎትን HTTPS ሊንክ ይክፈቱ።
6. በAndroid Chrome ምናሌ (⋮) > Install app ወይም Add to Home screen ይምረጡ።

ማስታወሻዎች:
- የምግብ ፎቶዎች ከUnsplash ምስል አድራሻዎች ይጫናሉ፤ ስለዚህ ለፎቶዎች ኢንተርኔት ያስፈልጋል።
- የእድገት መዝገብ በአካባቢያዊ የbrowser storage ውስጥ ይቀመጣል፤ ወደ ሌላ ስልክ በራስ-ሰር አይተላለፍም።
- ይህ የመጀመሪያ ስሪት ነው፤ የምግብ መመሪያዎችን በልጁ ዕድሜ፣ አለርጂ፣ የመዋጥ ችሎታ እና የጤና ባለሙያ ምክር መሠረት ያስተካክሉ።
